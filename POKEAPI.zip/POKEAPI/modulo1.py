
import modulo2 as pokefuncionpt2
import matplotlib.pyplot as plt
from datetime import datetime
import os
import requests
import random

def obtener_lista_pokemones():
    url_base = "https://pokeapi.co/api/v2/pokemon?limit=1000"
    pokefuncionpt2.guardar_consulta_api_txt(url_base)

    try:
        respuesta = requests.get(url_base)
        if respuesta.status_code == 200:
            datos_pokemones = respuesta.json()
            nombres_pokemones = [pokemon['name'] for pokemon in datos_pokemones['results']]
            return nombres_pokemones
        else:
            print(f"Error {respuesta.status_code}: No se pudo obtener la lista de Pokemon.")
            return None
    except Exception as e:
        print(f"Ocurrio un error: {e}")
        return None

def obtener_info_pokemon(nombre_pokemon, caso):
    url_base = "https://pokeapi.co/api/v2/pokemon/"
    url_pokemon = url_base + nombre_pokemon.lower()

    try:
        respuesta = requests.get(url_pokemon)
        pokefuncionpt2.guardar_consulta_api_txt(url_pokemon)

        if respuesta.status_code == 200:
            datos_pokemon = respuesta.json()
            
            if caso == 'print':
                print(f"Nombre: {datos_pokemon['name'].capitalize()}")
                print(f"ID: {datos_pokemon['id']}")
                print("Tipos:")
                for tipo in datos_pokemon['types']:
                    print(f" - {tipo['type']['name'].capitalize()}")
                print(f"Peso: {datos_pokemon['weight']} hectogramos")
                print(f"Altura: {datos_pokemon['height']} decimetros")
                print("Habilidades:")
                for habilidad in datos_pokemon['abilities']:
                    print(f" - {habilidad['ability']['name'].capitalize()}")
                print("Estadisticas Base:")
                for stat in datos_pokemon['stats']:
                    print(f" - {stat['stat']['name'].capitalize()}: {stat['base_stat']}")
                print("Sprites:")
                print(f" - Frente: {datos_pokemon['sprites']['front_default']}")
                print(f" - Espalda: {datos_pokemon['sprites']['back_default']}")
                
                decision = input("¿Deseas guardar los datos en un archivo de texto? (s/n): ").lower()
                if decision == 's':
                    pokefuncionpt2.guardar_en_archivo(datos_pokemon, nombre_pokemon)
                
            elif caso == 'noprint':
                # Devolvemos la informacion en lugar de imprimir
                return {
                    'name': datos_pokemon['name'].capitalize(),
                    'id': datos_pokemon['id'],
                    'types': [tipo['type']['name'].capitalize() for tipo in datos_pokemon['types']],
                    'weight': datos_pokemon['weight'],
                    'height': datos_pokemon['height'],
                    'abilities': [habilidad['ability']['name'].capitalize() for habilidad in datos_pokemon['abilities']],
                    'stats': {stat['stat']['name'].capitalize(): stat['base_stat'] for stat in datos_pokemon['stats']},
                    'front_sprite': datos_pokemon['sprites']['front_default'],
                    'back_sprite': datos_pokemon['sprites']['back_default']
                }
            else:
                print("Caso no valido. Por favor, utiliza 'print' o 'noprint'.")
        else:
            print(f"Error {respuesta.status_code}: No se pudo obtener la informacion del Pokemon.")
    except Exception as e:
        print(f"Ocurrio un error: {e}")
        return None
   
        
def comparar_stats_pokemones(pokemon1, pokemon2):
    try:
        stats_pokemon1 = pokefuncionpt2.obtener_stats_pokemon(pokemon1)
        stats_pokemon2 = pokefuncionpt2.obtener_stats_pokemon(pokemon2)

        if stats_pokemon1 is not None and stats_pokemon2 is not None:
            print(f"Comparacion de estadisticas entre {pokemon1.capitalize()} y {pokemon2.capitalize()}:")
            for stat, valor_pokemon1 in stats_pokemon1.items():
                valor_pokemon2 = stats_pokemon2[stat]
                if valor_pokemon1 > valor_pokemon2:
                    print(f" - {pokemon1.capitalize()} tiene un {stat} mayor que {pokemon2.capitalize()}.")
                elif valor_pokemon1 < valor_pokemon2:
                    print(f" - {pokemon2.capitalize()} tiene un {stat} mayor que {pokemon1.capitalize()}.")
                else:
                    print(f" - {pokemon1.capitalize()} y {pokemon2.capitalize()} tienen el mismo {stat}.")

            nombres_stats = list(stats_pokemon1.keys())
            valores_pokemon1 = list(stats_pokemon1.values())
            valores_pokemon2 = list(stats_pokemon2.values())

            x = range(len(nombres_stats))
            width = 0.35

            fig, ax = plt.subplots()
            ax.bar(x, valores_pokemon1, width, label=pokemon1.capitalize())
            ax.bar([i + width for i in x], valores_pokemon2, width, label=pokemon2.capitalize())

            ax.set_xlabel('Estadisticas')
            ax.set_ylabel('Valor')
            ax.set_title('Comparacion de Estadisticas Base')
            ax.set_xticks([i + width / 2 for i in x])
            ax.set_xticklabels(nombres_stats)
            ax.legend()
            
            decision = input("¿Deseas ver y guardar la grafica? (s/n): ").lower()
            if decision == 's':
                carpeta = 'Graficas'
                archivo = f"stats-{pokemon1}-{pokemon2}"
                ruta_archivo = os.path.join(carpeta, f"{archivo}_{datetime.now().strftime("%d-%m-%Y_%H-%M-%S")}.png")
                plt.savefig(ruta_archivo)
                print(f"La grafica ha sido guardada en {ruta_archivo}")
                plt.show()
            elif decision == 'n':
                plt.close()
            else:
                print("Opcion no valida. La grafica no ha sido guardada ni mostrada.")
                plt.close()
            
        else:
            print("No se pudo realizar la comparacion debido a errores en la obtencion de datos.")
    except requests.exceptions.RequestException as e:
        print(f"Error de solicitud: {e}")
    except ValueError as e:
        print(f"Error al procesar los datos: {e}")
    except Exception as e:
        print(f"Ocurrió un error inesperado: {e}")
        
        
def comparar_pokemones(pokemon1, pokemon2):
    try:
        datos_pokemon1 = obtener_info_pokemon(pokemon1, 'noprint')
        datos_pokemon2 = obtener_info_pokemon(pokemon2, 'noprint')

        if datos_pokemon1 is not None and datos_pokemon2 is not None:
            peso_pokemon1 = datos_pokemon1['weight']
            peso_pokemon2 = datos_pokemon2['weight']

            altura_pokemon1 = datos_pokemon1['height']
            altura_pokemon2 = datos_pokemon2['height']

            habilidades_pokemon1 = len(datos_pokemon1['abilities'])
            habilidades_pokemon2 = len(datos_pokemon2['abilities'])

            print(f"Comparacion entre {pokemon1.capitalize()} y {pokemon2.capitalize()}:")
            if peso_pokemon1 > peso_pokemon2:
                print(f" - {pokemon1.capitalize()} es mas pesado que {pokemon2.capitalize()}.")
            elif peso_pokemon1 < peso_pokemon2:
                print(f" - {pokemon2.capitalize()} es mas pesado que {pokemon1.capitalize()}.")

            if altura_pokemon1 > altura_pokemon2:
                print(f" - {pokemon1.capitalize()} es mas alto que {pokemon2.capitalize()}.")
            elif altura_pokemon1 < altura_pokemon2:
                print(f" - {pokemon2.capitalize()} es mas alto que {pokemon1.capitalize()}.")

            if habilidades_pokemon1 > habilidades_pokemon2:
                print(f" - {pokemon1.capitalize()} tiene mas habilidades que {pokemon2.capitalize()}.")
            elif habilidades_pokemon1 < habilidades_pokemon2:
                print(f" - {pokemon2.capitalize()} tiene mas habilidades que {pokemon1.capitalize()}.")

            if peso_pokemon1 == peso_pokemon2 and altura_pokemon1 == altura_pokemon2 and habilidades_pokemon1 == habilidades_pokemon2:
                print(f" - {pokemon1.capitalize()} y {pokemon2.capitalize()} son identicos en peso, altura y habilidades.")
                
            etiquetas = [f'{pokemon1.capitalize()}', f'{pokemon2.capitalize()}']
            valores = [peso_pokemon1, peso_pokemon2]

            plt.bar(etiquetas, valores)
            plt.title('Comparacion de Peso entre Pokemon')
            plt.ylabel('Peso')
            
            decision = input("¿Deseas ver y guardar la grafica? (s/n): ").lower()
            if decision == 's':
                carpeta = 'Graficas'
                archivo = f"comparacion-{pokemon1}-{pokemon2}"
                ruta_archivo = os.path.join(carpeta, f"{archivo}_{datetime.now().strftime("%d-%m-%Y_%H-%M-%S")}.png")
                plt.savefig(ruta_archivo)
                print(f"La grafica ha sido guardada en {ruta_archivo}")
                plt.show()
            elif decision == 'n':
                plt.close()
            else:
                print("Opcion no valida. La grafica no ha sido guardada ni mostrada.")
                plt.close()
                
        else:
            print("No se pudo realizar la comparacion debido a errores en la obtencion de datos.")
    except Exception as e:
        print(f"Ocurrió un error: {e}")
        
        
def comparar_stats_pokemones_random(lista_pokemones):
    try:
        pokemon_seleccionados = random.sample(lista_pokemones, 5)

        for i in range(1):
            for j in range(i + 1, 2):
                pokemon1 = pokemon_seleccionados[i]
                pokemon2 = pokemon_seleccionados[j]

                stats_pokemon1 = pokefuncionpt2.obtener_stats_pokemon(pokemon1)
                stats_pokemon2 = pokefuncionpt2.obtener_stats_pokemon(pokemon2)

                if stats_pokemon1 is not None and stats_pokemon2 is not None:
                    print(f"Comparacion de estadisticas entre {pokemon1.capitalize()} y {pokemon2.capitalize()}:")
                    for stat, valor_pokemon1 in stats_pokemon1.items():
                        valor_pokemon2 = stats_pokemon2[stat]
                        if valor_pokemon1 > valor_pokemon2:
                            print(f" - {pokemon1.capitalize()} tiene un {stat} mayor que {pokemon2.capitalize()}.")
                        elif valor_pokemon1 < valor_pokemon2:
                            print(f" - {pokemon2.capitalize()} tiene un {stat} mayor que {pokemon1.capitalize()}.")
                        else:
                            print(f" - {pokemon1.capitalize()} y {pokemon2.capitalize()} tienen el mismo {stat}.")

                    nombres_stats = list(stats_pokemon1.keys())
                    valores_pokemon1 = list(stats_pokemon1.values())
                    valores_pokemon2 = list(stats_pokemon2.values())

                    x = range(len(nombres_stats))
                    width = 0.35

                    fig, ax = plt.subplots()
                    ax.bar(x, valores_pokemon1, width, label=pokemon1.capitalize())
                    ax.bar([i + width for i in x], valores_pokemon2, width, label=pokemon2.capitalize())

                    ax.set_xlabel('Estadisticas')
                    ax.set_ylabel('Valor')
                    ax.set_title('Comparacion de Estadisticas Base')
                    ax.set_xticks([i + width / 2 for i in x])
                    ax.set_xticklabels(nombres_stats)
                    ax.legend()

                    decision = input("¿Deseas ver y guardar la grafica? (s/n): ").lower()
                    if decision == 's':
                        carpeta = 'Graficas'
                        archivo = f"stats-{pokemon1}-{pokemon2}"
                        ruta_archivo = os.path.join(carpeta, f"{archivo}_{datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.png")
                        plt.savefig(ruta_archivo)
                        print(f"La grafica ha sido guardada en {ruta_archivo}")
                        plt.show()
                    elif decision == 'n':
                        plt.close()
                    else:
                        print("Opcion no valida. La grafica no ha sido guardada ni mostrada.")
                        plt.close()
                else:
                    print("No se pudo realizar la comparacion debido a errores en la obtencion de datos.")
    except Exception as e:
        print(f"Ocurrió un error: {e}")