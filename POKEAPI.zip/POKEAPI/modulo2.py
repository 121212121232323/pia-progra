import requests
import openpyxl
import modulo1 as pokefuncionpt1
import matplotlib.pyplot as plt
from datetime import datetime
import os

def buscar_pokemon_en_lista(nombre_pokemon, lista_pokemones):
    nombre_pokemon = nombre_pokemon.lower()

    if nombre_pokemon in lista_pokemones:
        return True
    else:
        return False
    
def obtener_stats_pokemon(nombre_pokemon):
    url_base = "https://pokeapi.co/api/v2/pokemon/"

    url_pokemon = url_base + nombre_pokemon.lower()

    try:
        respuesta = requests.get(url_pokemon)
        guardar_consulta_api_txt(url_pokemon)

        if respuesta.status_code == 200:
            datos_pokemon = respuesta.json()

            stats = {
                'ataque': datos_pokemon['stats'][1]['base_stat'],
                'defensa': datos_pokemon['stats'][2]['base_stat'],
                'ataque_especial': datos_pokemon['stats'][3]['base_stat'],
                'defensa_especial': datos_pokemon['stats'][4]['base_stat'],
                'velocidad': datos_pokemon['stats'][5]['base_stat']
            }

            return stats
        else:
            print(f"Error {respuesta.status_code}: No se pudo obtener la información del Pokémon.")
            return None
    except requests.exceptions.HTTPError as http_err:
        print(f"Error HTTP al obtener la información del Pokémon: {http_err}")
        return None

    except requests.exceptions.RequestException as req_err:
        print(f"Error al realizar la solicitud a la API: {req_err}")
        return None

    except Exception as e:
        print(f"Ocurrió un error: {e}")
        return None


def obtener_tipos_pokemones(lista_pokemones):
    tipos_pokemones = {}

    url_base = "https://pokeapi.co/api/v2/pokemon/"
    
    total_pokemones = len(lista_pokemones)
    
    porcentaje_imprimir = 10
    incremento_porcentaje = 10
    print("Cargando: ")
    
    for i, nombre_pokemon in enumerate(lista_pokemones, start=1):
        
        url_pokemon = url_base + nombre_pokemon.lower()
        if i / total_pokemones * 100 >= porcentaje_imprimir:
            print(f'\r{porcentaje_imprimir}%', end='', flush=True)
            porcentaje_imprimir += incremento_porcentaje

        try:
            respuesta = requests.get(url_pokemon)
            guardar_consulta_api_txt(url_pokemon)

            if respuesta.status_code == 200:
                datos_pokemon = respuesta.json()

                tipos = [tipo['type']['name'].capitalize() for tipo in datos_pokemon['types']]

                tipos_pokemones[nombre_pokemon] = tipos
            else:
                print(f"No se pudo obtener la información del Pokémon {nombre_pokemon.capitalize()}.")
        except Exception as e:
            print(f"Error al obtener información del Pokémon {nombre_pokemon.capitalize()}: {e}")

    return tipos_pokemones


def graficar_tipos_pokemon(tipos_pokemones):
    try:
        frecuencia_tipos = {}

        for tipos in tipos_pokemones.values():
            for tipo in tipos:
                if tipo in frecuencia_tipos:
                    frecuencia_tipos[tipo] += 1
                else:
                    frecuencia_tipos[tipo] = 1

        tipos = list(frecuencia_tipos.keys())
        frecuencias = list(frecuencia_tipos.values())
        
        contador_frecuencias = {}
        for tipo, frecuencia in zip(tipos, frecuencias):
            if tipo in contador_frecuencias:
                contador_frecuencias[tipo] += frecuencia
            else:
                contador_frecuencias[tipo] = frecuencia

        tipo_moda = max(contador_frecuencias, key=contador_frecuencias.get)
        frecuencia_moda = contador_frecuencias[tipo_moda]

        tipo_min = min(contador_frecuencias, key=contador_frecuencias.get)
        frecuencia_min = contador_frecuencias[tipo_min]

        tipo_max = max(contador_frecuencias, key=contador_frecuencias.get)
        frecuencia_max = contador_frecuencias[tipo_max]

        print(f"Tipo con la frecuencia mínima: {tipo_min}, Frecuencia: {frecuencia_min}")
        print(f"Tipo con la frecuencia máxima: {tipo_max}, Frecuencia: {frecuencia_max}")

        print(f"Moda de tipos de Pokemon: {tipo_moda}")
        
        plt.bar(tipos, frecuencias, color='purple')
        plt.xlabel('Tipos de Pokémon')
        plt.ylabel('Frecuencia')
        plt.title('Frecuencia de Tipos de Pokémon')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()

        decision = input("¿Deseas ver y guardar la gráfica? (s/n): ").lower()
        if decision == 's':
            carpeta = 'Graficas'
            archivo = f"Frecuencia_Tipos_Pokémon"
            ruta_archivo = os.path.join(carpeta, f"{archivo}_{datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.png")
            plt.savefig(ruta_archivo)
            print(f"La gráfica ha sido guardada en {ruta_archivo}")
            plt.show()
        elif decision == 'n':
            plt.close()
        else:
            print("Opción no válida. La gráfica no ha sido guardada ni mostrada.")
            plt.close()
    except Exception as e:
        print(f"Error al graficar tipos de Pokémon: {e}")
        
        
def guardar_en_excel(nombres_pokemones):
    try:
        carpeta = 'Reportes'
        archivo = f"Pokemones"
        ruta_archivo = os.path.join(carpeta, f"{archivo}_{datetime.now().strftime('%d-%m-%Y')}.xlsx")
        libro_excel = openpyxl.Workbook()

        if "Sheet" in libro_excel.sheetnames:
            del libro_excel["Sheet"]

        hoja_excel_nm = 'Nombres Pokemon'
        libro_excel.create_sheet(title=hoja_excel_nm)
        hoja_excel = libro_excel[hoja_excel_nm]

        for i, nombre in enumerate(nombres_pokemones, start=1):
            hoja_excel.cell(row=i, column=1, value=nombre)

        libro_excel.save(ruta_archivo)
        print(f"Los nombres de los Pokémon han sido guardados en {ruta_archivo}.")
    except Exception as e:
        print(f"Error al guardar en el archivo: {e}")
    
    
def guardar_en_archivo(datos, nombre):
    try:
        carpeta = 'Reportes'
        nombre_archivo = f"{nombre}_datos_{datetime.now().strftime('%d-%m-%Y')}.txt"
        ruta_archivo = os.path.join(carpeta, nombre_archivo)
        
        with open(ruta_archivo, 'w', encoding='utf-8') as archivo:
            
            archivo.write("Datos del Pokémon:\n")
            archivo.write(f"Nombre: {datos['name']}\n")
            archivo.write(f"ID: {datos['id']}\n")
            archivo.write("Tipos:\n")
            
            for tipo in datos['types']:
                archivo.write(f" - {tipo}\n")
                
            archivo.write(f"Peso: {datos['weight']} hectogramos\n")
            archivo.write(f"Altura: {datos['height']} decímetros\n")
            archivo.write("Habilidades:\n")
            
            for habilidad in datos['abilities']:
                archivo.write(f" - {habilidad}\n")
                
            archivo.write("Estadísticas Base:\n")
            
        print(f"Los datos del Pokémon han sido guardados en {nombre_archivo}.")
    except Exception as e:
        print(f"Error al guardar en el archivo: {e}")    
        

def guardar_consulta_api_txt(url):
    try:
        carpeta='Consulta API'
        fecha_actual = datetime.now().strftime("%d-%m-%Y")
        hora_actual = datetime.now().strftime("%H:%M:%S")

        archivo = "consulta"
        ruta_archivo_txt = os.path.join(carpeta, f"{archivo}_{fecha_actual}.txt")

        with open(ruta_archivo_txt, 'a', encoding='utf-8') as archivo:
            archivo.write(f"Consulta API\nFecha: {fecha_actual}\nHora: {hora_actual}\n")
            archivo.write(f"Consulta hecha a: {url}\n\n")

    except Exception as e:
        print(f"Error al hacer la consulta API: {e}")
