import modulo1 as pokefuncionpt1
import modulo2 as pokefuncionpt2
import os
import subprocess
import sys

def modulos():
    requerits = ['requests', 'os', 'datetime', 'collections', 'matplotlib.pyplot', 're', 'openpyxl', 'collections']
    non = []
    for modulo in requerits:
        try:
            __import__(modulo)
        except ImportError:
            non.append(modulo)

    if non:
        print("Faltan los siguientes modulos:")
        for modulo in non:
            print(f"- {modulo}")
            sys(exit)
    else:
        print("Todos los modulos instalados.")

# Main
if __name__ == "__main__":
    modulos()
    if len(sys.argv) < 1:
        lista_pokemones = pokefuncionpt1.obtener_lista_pokemones()
        pikachu = sys.argv[1].lower
        if len(sys.argv) != 2:
            print("Formato: python script.py pokemon")
            sys.exit(1)
        if pokefuncionpt2.buscar_pokemon_en_lista(pikachu, lista_pokemones):
            pokefuncionpt1.obtener_info_pokemon(pikachu, 'print')
        else:
            print(f"{pikachu.capitalize()} no existe.")
            
    lista_pokemones = pokefuncionpt1.obtener_lista_pokemones()
    pokefuncionpt2.guardar_en_excel(lista_pokemones)
    lista_pokemones2 = lista_pokemones[:1]
    lista_tipo_pokemones = pokefuncionpt2.obtener_tipos_pokemones(lista_pokemones2)
    while True:
        os.system('cls')
        print("Menu Principal:")
        print("a) Obtener datos de un Pokemon")
        print("b) Comparar estadisticas de Pokemones")
        print("c) Comparar Pokemones")
        print("d) Comparar Pokemones random")
        print("e) Tipos de Pokemon")
        print("f) Salir")
        opcion = input("Seleccione una opcion: ").lower()
        print("")
        if opcion == 'a':
            while True:
                pokemon_a1 = input("Ingrese el nombre de un Pokemon: ")
                if pokefuncionpt2.buscar_pokemon_en_lista(pokemon_a1, lista_pokemones):
                    break
                else:
                    print(f"{pokemon_a1.capitalize()} no existe, ingresa otro Pokemon.")
            pokefuncionpt1.obtener_info_pokemon(pokemon_a1, 'print')
            input("Continua?")
        elif opcion == 'b':
            while True:
                pokemon_b1 = input("Ingrese el nombre del primer Pokemon: ")
                if pokefuncionpt2.buscar_pokemon_en_lista(pokemon_b1, lista_pokemones):
                    break
                else:
                    print(f"{pokemon_a1.capitalize()} no existe, ingresa otro Pokemon.")
            while True:
                pokemon_b2 = input("Ingrese el nombre del segundo Pokemon: ")
                if pokefuncionpt2.buscar_pokemon_en_lista(pokemon_b2, lista_pokemones):
                    break
                else:
                    print(f"{pokemon_a1.capitalize()} no existe, ingresa otro Pokemon.")
            pokefuncionpt1.comparar_stats_pokemones(pokemon_b1, pokemon_b2)
            input("Continua?")
        elif opcion == 'c':
            while True:
                pokemon_b1 = input("Ingrese el nombre del primer Pokemon: ")
                if pokefuncionpt2.buscar_pokemon_en_lista(pokemon_b1, lista_pokemones):
                    break
                else:
                    print(f"{pokemon_a1.capitalize()} no existe, ingresa otro Pokemon.")
            while True:
                pokemon_b2 = input("Ingrese el nombre del segundo Pokemon: ")
                if pokefuncionpt2.buscar_pokemon_en_lista(pokemon_b2, lista_pokemones):
                    break
                else:
                    print(f"{pokemon_a1.capitalize()} no existe, ingresa otro Pokemon.")
            pokefuncionpt1.comparar_pokemones(pokemon_b1, pokemon_b2)
            input("Continua?")
        elif opcion == 'd':
            pokefuncionpt1.comparar_stats_pokemones_random(lista_pokemones)
            input("Continua?")
        elif opcion == 'e':
            pokefuncionpt2.graficar_tipos_pokemon(lista_tipo_pokemones)
            input("Continua?")
        elif opcion == 'f':
            break
        else:
            print("Opcion no valida. Por favor, seleccione una opcion valida.")
